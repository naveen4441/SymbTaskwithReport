package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class SymdTask {
	

	   private static final Logger logger = LogManager.getLogger(SymdTask.class); // Initialize logger
       WebDriver driver;
       static ExtentTest test;
       static ExtentReports report;
       ExtentSparkReporter extentSparkReporter;
       ExtentReports extentReports;
       ExtentTest extentTest;
       //WebDriverWait wait = new WebDriverWait(driver,30);
	    @BeforeClass
	    public void setup() {
	        // Initialize the WebDriver and open the URL
	    	Reporter.log("Setting up the WebDriver and opening the URL");
	    	logger.info("Setting up the WebDriver and opening the URL");
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        driver.get("https://d3pv22lioo8876.cloudfront.net/tiptop/");
	        Reporter.log("Navigated to the URL successfully");
	        logger.info("Navigated to the URL successfully");
	      //  report = new ExtentReports();
	       // test = report.createTest(null);
	        extentSparkReporter  = new ExtentSparkReporter(System.getProperty("user.dir") + "/ExtendReport/extentReport.html");
	        extentReports = new ExtentReports();
	        extentReports.attachReporter(extentSparkReporter);


	        //configuration items to change the look and feel
	        //add content, manage tests etc
	        extentSparkReporter.config().setDocumentTitle("Simple Automation Report");
	        extentSparkReporter.config().setReportName("Test Report");
	        extentSparkReporter.config().setTheme(Theme.STANDARD);
	        extentSparkReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
	    }  public void getResult(ITestResult result) {
	        if(result.getStatus() == ITestResult.FAILURE) {
	            extentTest.log(Status.FAIL,result.getThrowable());
	        }
	        else if(result.getStatus() == ITestResult.SUCCESS) {
	            extentTest.log(Status.PASS, result.getTestName());
	        }
	        else {
	            extentTest.log(Status.SKIP, result.getTestName());
	        }
	    }


	    @Test(priority = 1)
	    public void verifyDisabledInput() {
	    	extentTest = extentReports.createTest("verifyDisabledInput", "This test case has passed");
	    	Reporter.log("Verifying that the input is disabled");
	    	logger.info("Verifying that the input is disabled");
	        // Verify that the input is disabled
	        WebElement disabledInput = driver.findElement(By.xpath("(//input[@name='my-disabled'])[1]"));
	        Assert.assertFalse(disabledInput.isEnabled(), "Input is not disabled");
	        Reporter.log("Verified that the input is disabled successfully");
	        logger.info("Verified that the input is disabled successfully");
	        extentReports.flush();
	    }
	  
	    @Test(priority = 2)
	    public void verifyReadonlyInput() {
	    	extentTest = extentReports.createTest("verifyReadonlyInput", "This test case has passed");
	    	Reporter.log("Verifying readonly input fields");
	    	logger.info("Verifying readonly input fields");
	        // Verify readonly input using two xpaths
	        WebElement readonlyInput1 = driver.findElement(By.xpath("//input[@value='Readonly input']"));
	        WebElement readonlyInput2 = driver.findElement(By.xpath("//input[@readonly and @value='Readonly input']"));

	        Assert.assertTrue(readonlyInput1.getAttribute("readonly").equals("true"), "Input is readonly with 1st xpath");
	        Reporter.log("Verified readonly input fields successfully with Xpath1");
	        logger.info("Verified readonly input fields successfully with Xpath1");
	        
	        Assert.assertTrue(readonlyInput2.getAttribute("readonly").equals("true"), "Input is readonly (2nd XPath)");
	        Reporter.log("Verified readonly input fields successfully with Xpath2");
	        logger.info("Verified readonly input fields successfully with Xpath2");
	        extentReports.flush();
	    }

	    @Test(priority = 3)
	    public void verifyDropdownElements() {
	    	extentTest = extentReports.createTest("verifyDropdownElements", "This test case has passed");
	    	Reporter.log("Verifying the dropdown elements");
	    	logger.info("Verifying the dropdown elements");
	        // Verify the dropdown has 8 elements using two xpaths
	        //WebElement dropdown = driver.findElement(By.xpath("//select[@name='my-select']"));
	        List<WebElement> options1 = driver.findElements(By.tagName("option"));
	        Assert.assertEquals(options1.size(), 8, "Dropdown have 8 options using 1st Xpath");

	        List<WebElement> options2 = driver.findElements(By.xpath("//select[@name='my-select']/option"));
	        Assert.assertEquals(options2.size(), 8, "Dropdown does 8 options using 2nd xpath");
	        Reporter.log("Verified dropdown elements successfully");
	        logger.info("Verified dropdown elements successfully");
	        extentReports.flush();
	    }

	    @Test(priority = 4)
	    public void verifySubmitButtonDisabled() {
	    	extentTest = extentReports.createTest("verifySubmitButtonDisabled", "This test case has passed");
	    	Reporter.log("Verifying that the submit button is disabled when Name & Password fields are empty");
	    	logger.info("Verifying that the submit button is disabled when Name & Password fields are empty");
	        // Verify the submit button is disabled when the Name field is empty
	        WebElement submitButton = driver.findElement(By.xpath("//button[@type='submit']"));
	        Assert.assertFalse(submitButton.isEnabled(), "Submit button is disabled when Name & password field is empty");
	        Reporter.log("Verified that submit button is disabled successfully");
	        logger.info("Verified that submit button is disabled successfully");
	        extentReports.flush();
	    }

	    @Test(priority = 5)
	    public void verifySubmitButtonEnabledwithNameAndPassword() throws InterruptedException {
	    	extentTest = extentReports.createTest("verifySubmitButtonEnabledwithNameAndPassword", "This test case has passed");
	    	Reporter.log("Verifying that the submit button is enabled when Name and Password fields are filled");
	    	logger.info("Verifying that the submit button is enabled when Name and Password fields are filled");
	        // Verify the submit button is enabled when Name and Password fields are filled
	        WebElement nameInput = driver.findElement(By.xpath("//input[@name='my-name']"));
	        nameInput.sendKeys("Naveen");
	        WebElement passwordInput = driver.findElement(By.xpath("//input[@name='my-password']"));
	        
	        passwordInput.sendKeys("naveen");
	        WebElement submitButton = driver.findElement(By.xpath("//button[@type='submit']"));
	        
	        Thread.sleep(4000);

	        Assert.assertTrue(submitButton.isEnabled(), "Submit button is  enabled after filling Name and Password");
	        Reporter.log("Verified that submit button is enabled successfully");
	        logger.info("Verified that submit button is enabled successfully");
	        extentReports.flush();
	    }

	    @Test(priority = 6)
	    public void verifySubmitDisplaysReceivedText() throws InterruptedException {
	    	extentTest = extentReports.createTest("verifySubmitDisplaysReceivedText", "This test case has passed");
	    	Reporter.log("Verifying the 'Received' text after form submission");
	    	logger.info("Verifying the 'Received' text after form submission");
	        // Verify the page shows "Received" text upon submission
	        WebElement submitButton = driver.findElement(By.xpath("//button[@type='submit']"));
	        submitButton.click();
            Thread.sleep(4000);
	        WebElement receivedText = driver.findElement(By.xpath("//p[contains(text(), 'Received')]"));
	        String recivedActual=receivedText.getText().replace("!", "");
	        Assert.assertEquals(recivedActual, "Received", "'Received' text displayed after submission");
	        Reporter.log("Verified that 'Received' text is displayed successfully");
	        logger.info("Verified that 'Received' text is displayed successfully");
	        extentReports.flush();
	    }

	    @Test(priority = 7)
	    public void verifyFormDataInURL() {
	    	extentTest = extentReports.createTest("verifyFormDataInURL", "This test case has passed");
	    	Reporter.log("Verifying form data in the URL");
	    	logger.info("Verifying form data in the URL");
	        // Verify all form data is passed to the URL
	        String currentUrl = driver.getCurrentUrl();
	        Assert.assertTrue(currentUrl.contains("name=Naveen"), "Name data  passed in URL");
	        Reporter.log("Verified that nane is present in the URL");
	        logger.info("Verified that nane is present in the URL");
	        
	        Assert.assertTrue(currentUrl.contains("password=naveen"), "Password data passed in URL");
	        Reporter.log("Verified that password is present in the URL");
	        logger.info("Verified that password is present in the URL");
	        
            Assert.assertTrue(currentUrl.contains("my-readonly=Readonly"), "Readonly field data  passed in URL");
            Reporter.log("Verified that readonly is present in the URL");
            logger.info("Verified that readonly is present in the URL");
            
	        Assert.assertTrue(currentUrl.contains("my-select=white"), "Select color data passed in URL");
	        Reporter.log("Verified that colur is present in the URL");
	        logger.info("Verified that colur is present in the URL");
	        extentReports.flush();

	    }

	  
		@AfterClass
	    public void tearDown() {
			Reporter.log("Tearing down the WebDriver and closing the browser");
			logger.info("Tearing down the WebDriver and closing the browser");
	        // Close the browser
	        if (driver != null) {
	            driver.quit();
	        Reporter.log("Browser closed successfully");
	        logger.info("Browser closed successfully");
	        
	        }
	    }
	}

